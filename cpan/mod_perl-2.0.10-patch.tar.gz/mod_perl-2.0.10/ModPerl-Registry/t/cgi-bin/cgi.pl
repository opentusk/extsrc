# please insert nothing before this line: -*- mode: cperl; cperl-indent-level: 4; cperl-continued-statement-offset: 4; indent-tabs-mode: nil -*-
use CGI qw/:standard :html3/;

print header(-type=>'text/html');
print b("done");
